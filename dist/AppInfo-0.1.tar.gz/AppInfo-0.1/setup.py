from distutils.core import setup

setup(
    name='AppInfo',
    version='0.1',
    packages=['package'],
    url='',
    license='',
    author='',
    scripts=["runner"],
    author_email='ccepl.kunal@gmail.com',
    description=''
)
